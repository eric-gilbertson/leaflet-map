/* Description:
 * This file implements the actions require to get the block,
 * and plantings data from the server detail REST quries.
 */

// Unlike ajax, fetch requires the credentials header.
// Use this global for all our fetch requests.
//import { checkHttpStatus, parseJSON, getCsrfToken } from '../../../utils';

const REQUEST_OPTIONS = {
    credentials: "same-origin",
    'Access-Control-Allow-Origin' : '*',
    'content-type': 'application/json',
};

// constants used to identify the block info actions
export const CLEAR_BLOCK_INFO = 'CLEAR_BLOCK_INFO';
export const GET_BLOCK_INFO = 'GET_BLOCK_INFO';

export const GET_BLOCK_INFO_DONE = 'GET_BLOCK_INFO_DONE';
export const SAVE_BLOCK_INFO_DONE = 'SAVE_BLOCK_INFO_DONE';

export function getCsrfToken(name) {
  let match = document.cookie.match(new RegExp('(^| )csrftoken=([^;]+)'));
  if (match) return match[2];
}

export function getBlockInfoDone(block) {
    return {
        type: GET_BLOCK_INFO_DONE,
        blockInfo:block,
    };
}

export function clearBlockInfo() {
    return {
        type: CLEAR_BLOCK_INFO,
    };
}
export function saveBlockInfoDone() {
    return {
        type: SAVE_BLOCK_INFO_DONE,
    };
}

export function getBlockInfo(id) {
    return (dispatch) => {
        const url = `http://localhost:8080/farm/blocks/${id}`
        //const url = `/farm/blocks?block_id=${id}&include_irrigation_config_status=true&include_growing_seasons=true`;

            fetch(url, REQUEST_OPTIONS)
                .then((response) => {
                    if (!response.ok) {
                        throw Error(response.statusText);
                    }
                    return response;
                })
                .then((response) => response.json())
                .then(function(block) {
                    console.log('xxxxxxxxxxxxxxxxxx got data');
                    dispatch(getBlockInfoDone(block));
                }).catch((ex) => {
                    console.log("Error: fetching blockInfo ", ex);
                    dispatch(clearBlockInfo());
                });
   }
}

// constants used to identify the planting info actions
export const CLEAR_PLANTING_INFO = 'CLEAR_PLANTING_INFO';
export const GET_PLANTING_INFO = 'GET_PLANTING_INFO';

export const GET_PLANTING_INFO_DONE = 'GET_PLANTING_INFO_DONE';
export const SAVE_PLANTING_INFO_DONE = 'SAVE_PLANTING_INFO_DONE';

export function getPlantingInfoDone(planting) {
    return {
        type: GET_PLANTING_INFO_DONE,
        plantingInfo: planting,
    };
}

export function clearPlantingInfo() {
    return {
        type: CLEAR_PLANTING_INFO,
    };
}
export function savePlantingInfoDone() {
    return {
        type: SAVE_PLANTING_INFO_DONE,
    };
}

// Map the planting info into a single object in order to simplify
// presentation.
// Add references to all displayed data to a single
// object so that all display & update actions can go
// through it.
function populatePlantingData(planting) {
    let cropDetails = planting.crop_details;
    let irrigationCfg = planting.irrigation_configuration;
    let irrigationProps = irrigationCfg.irrigation_properties;

    const MAPPING_STRUCTS = [
        [cropDetails, 'crop_varietal', 'crop_class', 'crop_type_id', 'start_date', 'end_date'],
        [irrigationCfg, 'application_rate_24_hours', 'rate_gpm'],
        [irrigationProps, 'irrigation_system_type', 'drip_tapes_per_bed', 'number_of_sets', 'irrigation_efficiency', 'rows_per_bed', 'irrigation_efficiency', 'bed_width']
    ];

    let data = {};
    for(let i=0; i < MAPPING_STRUCTS.length; i++) {
        let struct = MAPPING_STRUCTS[i];
        let srcObj = struct[0];
        for (let j=1; j < struct.length; j++) {
            let key = struct[j];
            // map null to '' to supress react warnings
            data[key] = srcObj[key] === null ? "" : srcObj[key];
        }
    }

    // these must be set up manually
    data.is_configuration_finished = irrigationCfg.ui_wizard_state.isFinished;

    data.application_rate = irrigationProps.application_rate_then_units[0];
    data.application_rate_units = irrigationProps.application_rate_then_units[1];
    data.tree_spacing_x = irrigationProps.tree_spacing_row_x_alley_width[0];
    data.tree_spacing_y = irrigationProps.tree_spacing_row_x_alley_width[1]
    planting.data = data;

    console.log("data: ", data);
}


export function getPlantingInfo(id) {
    return (dispatch, getState) => {
        const url = `http://localhost:8080/irrigation/planting/${id}`;
        //const url = `/irrigation/planting?planting_id=${id}`;

            fetch(url, REQUEST_OPTIONS)
                .then((response) => {
                    if (!response.ok) {
                        throw Error(response.statusText);
                    }
                    return response;
                })
                .then((response) => response.json())
                .then(function(planting) {
                    console.log('xxxxxxxxxxxxxxxxxx got data');
                    populatePlantingData(planting);
                    dispatch(getPlantingInfoDone(planting));
                }).catch((ex) => {
                    console.log("Error: fetching plantingInfo ", ex);
                    dispatch(clearPlantingInfo());
                });
   }
}


export function savePlantingInfo(plantingInfo) {
    let plantingId = plantingInfo.planting_id;
    console.log("xxxxxxxxxxxxxx savePlantingInfo: ", plantingInfo);
    return (dispatch) => {
        const url = `http://localhost:8080/irrigation/planting/${plantingInfo.planting_id}`;
        //const url = `/irrigation/planting?planting_id=${plantingInfo.planting_id}`;
        const options = { 
            method: 'POST', 
            credentials: "include",
            headers: {
                'accept': 'application/json',
                'Access-Control-Allow-Origin' : '*',
                'content-type': 'application/json',
            },
            body: JSON.stringify(plantingInfo),
        };

        fetch(url , options).then((response) => {
            if (!response.ok) throw Error(response.statusText);
            return response;
        }).then(function(newPlanting) {
            // return object is incomplete so fetch it again.
            dispatch(getPlantingInfo(plantingId));
        }).catch(function(ex) {
            let msg = `Error: planting not saved: ${ex}`;
            console.log(msg);
            //TODO: dispatch error msg and show in page header.
            alert(msg);
        });
    };
}
/*
export function getBlockList() {
    return (dispatch) => {

        let url = '/dashboard/api/blocks/';
        fetch(url, REQUEST_OPTIONS).then((response) => {
                if (!response.ok) {
                    throw Error(response.statusText);
                }
                return response;
            })
            .then((response) => response.json())
            .then(function (blockList) {
               dispatch(getBlockListDone(blockList));
            }).catch(function(ex) {
               console.log("dispatch blockListErrored: ", ex); 
            });
    };
}

export function deleteBlock(blockId) {
    return (dispatch) => {
        const url = `/dashboard/api/blocks/${blockId}/`;
        const options = {
            method: 'DELETE', 
            credentials: "include",
            headers: {
                'accept': 'application/json',
                'content-type': 'application/json',
                'X-CSRFToken': getCsrfToken(),
            },
        };

        fetch(url, options).then((response) => {
            if (!response.ok) throw Error(response.statusText);
            return response;
        }).then(function () {
            dispatch(getBlockList());
        }).catch(function(ex) {
            console.log("Block delete error: ", ex); 
        });
    };
}


*/

