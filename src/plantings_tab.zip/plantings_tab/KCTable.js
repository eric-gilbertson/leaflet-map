/* Description:
 * Dislays the details associated with the active planting.
 */
import React, { Component } from 'react';
import PropTypes from 'prop-types';

    
//visible: is_active() && is_kc_table_visible() && !loading_kc_data()"
const KCTable = ({stageList}) => {
    let showCanopyMeasure = false;
    let showPartialIrrigation = false;
   
    return(
        <table className="kc-table table table-with-inner-inputs table-bordered margin-bottom">
            <thead>
                <tr>
                    <th>Stage</th>
                    { showCanopyMeasure && <th>Canopy Measure</th> }
                    <th>Kc</th>
                    { showPartialIrrigation && <th>Partial %</th> }
                    <th>Date this season</th>
                </tr>
            </thead>
            {stageList && 
                <tbody>{ stageList.map((stage, index) => { 
                    return(
                        <tr key={index}>
                            <td>{stage.name}</td>
                            {showCanopyMeasure && <td> {stage.reference_canopy_measure}</td>}
                            <td> {stage.kc_value}</td>
                            {showPartialIrrigation  && <td> {stage.partial_et_percent}</td>}
                            <td className="kc-table-date-this-season-cell">{stage.date_this_season_cell}</td>
                        </tr>)})
                }</tbody>
             }
          </table>
    )
}

export {KCTable};
