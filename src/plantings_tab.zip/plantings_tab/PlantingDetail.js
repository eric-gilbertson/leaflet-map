/* Description:
 * Dislays the details associated with the active planting.
 */
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
//import CROP_TYPES from '../../constants/CropTypes';
import CROP_TYPES from './CropTypes';

import { Button, Alert, Row, Col } from 'react-bootstrap/lib';

const PlantingDetail = ({planting, onInputChange}) => {
   if (!planting.crop_details)
       return('Loading....');

    let pdata = planting.data;
    let isTreeCrop = pdata.crop_class === 'Orchard';
    let treeCropDisplay = isTreeCrop ? 'block' : 'none'
    let rowCropDisplay = pdata.crop_class === 'Row' ? 'block' : 'none'
    let vineCropDisplay = pdata.crop_class === 'Vine' ? 'block' : 'none'
    let showIrrigation = pdata.is_configuration_finished;
    let applicationRateIsGallons = pdata.application_rate_units === 'gal_per_hr_per_tree';
    let showIrrigationStrategy = false;
    let irrigationType = pdata.irrigation_system_type;
    let showDripTapes = irrigationType === 'drip' || irrigationType === 'subsurface_drip';
    let isIrrigationConfigured = true;

    const  TREE_CROP_IRRIGATION_TYPES = [
            {name: "Drip",                      value: "drip"},
            {name: "Subsurface Drip",           value: "subsurface_drip"},
            {name: "Microsprinkler",            value: "microsprinkler"},
            {name: "Other",                     value: "other"}
    ];

    const  ROW_CROP_IRRIGATION_TYPES = [
            {name: "Drip",                      value: "drip"},
            {name: "Subsurface Drip",           value: "subsurface_drip"},
            {name: "Other",                     value: "other"}
    ];
 
    //TODO: check that this updates if category changes.
    let irrigationTypes = isTreeCrop ? TREE_CROP_IRRIGATION_TYPES : ROW_CROP_IRRIGATION_TYPES;

    console.log("xxxxxxxx: ", planting);
        return(
            <div>
                <Row>
                     <Col xs={3}>
                        <label htmlFor="cropType">Crop</label>
                        <br/>
                        <select  onChange={onInputChange} className="form-control" value={pdata.crop_type_id} name="crop_type_id">
                           {Object.keys(CROP_TYPES).map(function (key, index) {
                                let crop = CROP_TYPES[key];
                                return (
                                    <option key={index} value={crop.id}>{crop.name}</option>
                                );
                            })}
                        </select>
                     </Col>
                     <Col xs={3}>
                        <label htmlFor="varietalType">Varietal</label>
                        <input className="form-control" type="text"  onChange={onInputChange} value={pdata.crop_varietal} name="crop_varietal"></input>
                    </Col>
                    <Col xs={3}>
                        <label htmlFor="plantedDate">Planted</label>
                        <input className="form-control" type="value"  onChange={onInputChange} value={pdata.start_date}  name="start_date"></input>
                    </Col>
                    <Col xs={3}>
                        <label htmlFor="harvestedDate">Harvested </label>
                        <input className="form-control" type="value"   onChange={onInputChange} value={pdata.end_date} name="end_date"></input>
                    </Col>
                </Row>
                <div style={{'display': (isIrrigationConfigured ? 'block' : 'none')}}>
                    <Row style={{marginTop:'8px'}}>
                         <Col style={{'display': rowCropDisplay}} xs={3}>
                            <label htmlFor="bedWidth">Bed Width</label>
                            <input className="form-control" type="number"   onChange={onInputChange} value={pdata.bed_width} name="bed_width"></input>
                        </Col>
                        <Col style={{'display':treeCropDisplay}} className="form-group" xs={3}>
                                <label>Tree Spacing (ft)</label>
                                <div className="input-group">
                                    <input style={{width:'70px'}} type="number"  onChange={onInputChange} value={pdata.tree_spacing_x} name="tree_spacing_x" className="form-control"/>
                                    <span className="input-group-addon">x</span>
                                    <input style={{width:'70px'}}  onChange={onInputChange} value={pdata.tree_spacing_y} type="number" name="tree_spacing_y" className="form-control" />
                                </div>
                        </Col>
                        <Col xs={3}>
                            <label htmlFor="rowsPerBed">Rows per bed</label>
                            <input className="form-control"  onChange={onInputChange} value={pdata.rows_per_bed} type="number"  name="rows_per_bed"></input>
                        </Col>
                        <Col xs={3}>
                            <label htmlFor="fieldSets">Sets in Field</label>
                            <input className="form-control"  onChange={onInputChange} value={pdata.number_of_sets} type="number" name="number_or_sets"></input>
                        </Col>
                        <Col xs={3} style={{'display':(showDripTapes ? 'block' : 'none')}}>
                            <label htmlFor="bedDripTapes">Drip Tapes per bed </label>
                            <input className="form-control"  onChange={onInputChange} value={pdata.drip_tapes_per_bed} type="number" name="drip_tapes_per_bed"></input>
                        </Col>
                    </Row>
                    <Row>
                        <Col className="form-group" xs={3}>
                            <label>Irrigation System {pdata.irrigation_system_type}</label>
                            <select name="irrigation_system_type" className="form-control"  onChange={onInputChange} value={pdata.irrigation_system_type}>
                               {irrigationTypes.map(function (itype, index) {
                                    return (
                                        <option key={index} value={itype.value}>{itype.name}</option>
                                    );
                                })}
                            </select>
                        </Col>
                        <Col className="form-group" xs={3}>
                            <label>Application Rate</label>
                                <input type="number" name="application_rate"   onChange={onInputChange} value={pdata.application_rate} className="form-control" />
                                        <label className="text-left" style={{'paddingLeft': '5px'}}>
                                            <input onChange={onInputChange} type="radio" name="application_rate_units_orchard"   onChange={onInputChange} value="gal_per_hr_per_tree" checked={ (applicationRateIsGallons ? true : false)} /> gal / hr
                                        </label>
                                        <label className="text-left" style={{"paddingLeft": "5px"}}>
                                            <input type="radio" name="application_rate_units_orchard"   onChange={onInputChange} value="in_per_hr_per_acre" checked={ (applicationRateIsGallons ? false : true) } /> in / hr
                                        </label>
                        </Col>
                        <Col className="form-group" xs={3}>
                            <label>Irrigation Efficiency</label>
                            <input type="number" name="irrigation_efficiency" className="form-control" min="0" max="100" step="1"   onChange={onInputChange} value={pdata.irrigation_efficiency}/>
                        </Col>
                    </Row>
                    <Row>
                        <Col xs={6} className="">
                            <label>24 hour application rate: </label>
                            <span>{pdata.application_rate_24_hours} inches </span>
                        </Col>
                        <Col xs={6} className="text-right">
                            <label>Pump Load:&nbsp; </label>
                            <span>{parseInt(pdata.rate_gpm)} gallons/minute</span>
                        </Col>
                    </Row>
                    {showIrrigationStrategy && 
                        <Row>
                        <Col className="form-group" xs={4}>
                            <label>Irrigation Strategy</label>
                            <select name="irrigation_strategy" className="form-control">
                                <option>TBD</option>
                            </select>
                        </Col>
                        </Row>
                    }
               </div>
       </div>
   )
}

PlantingDetail.propTypes = {
    planting: PropTypes.object.isRequired,
    onInputChange: PropTypes.func.isRequired,
}

export default PlantingDetail;

