/* Description:
 */
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Alert, ButtonToolbar, Panel, PanelGroup, Button, Grid, Row, Col } from 'react-bootstrap/lib';

import { BlockName } from './BlockName';
import { KCTable } from './KCTable';
import { PlantingsList } from './PlantingsList';
import PlantingDetail from './PlantingDetail';
import {getPlantingInfo, savePlantingInfo} from './PlantingsActions';


const ConfigureIrrigationPanel = ({blockId}) => {
    console.log("blockId: ", blockId);
    return(
    <Row style={{marginTop:'16px', display:'flex', alignItems:'center'}}>
        <Col xs={12}>
            <Alert className={'warning" clearfix'}>
                <label>
                    Irrigation has not been configured for this field.
                </label>
                <a href={'/irrigation/configuration/wizard/' + blockId} style={{marginTop:'-4px'}}  className="btn btn-success pull-right">Configure Irrigation</a>
            </Alert>
        </Col>
    </Row>
    )
}

ConfigureIrrigationPanel.propTypes = {
    blockId: PropTypes.number.isRequired,
}

class PlantingsTab extends Component {
    constructor(props) {
      super(props);
 
      this.handleSelect = this.handleSelect.bind(this);
      this.handleCropChange = this.handleCropChange.bind(this);

      this.state = {
        expandedPanelAr: [false, true, false], 
        blockInfo: props.blockInfo,
        blockInfoChanged: false,
        plantingInfo: {},
      };

      //Needed only to squelch React warning.
      this._togglePanel = function() {
      }

      this._addPlanting = function() {
          console.log("add planting");
          let epa = this.state.expandedPanelAr.slice();
          epa[0] = true;
          this.setState({expandedPanelAr: epa});
      }

      this._onSave = function(event) {
          let plantingInfo = this.state.plantingInfo;
          if (!plantingInfo.planting_id) {
              alert("Save ignored - nothing has changed");
          } else {
              console.log("do Save: ", this.state.blockInfoChanged);
              this.props.updatePlanting(this.state.plantingInfo);
          }
      }

      // Handler for block name & ranch changes
      this._onBlockInfoChange = function(event) {
          console.log("xxxxxxx onInputChange: ", event.target.name, ", ", event.target.value);
          let target = event.target;
          let newInfo = Object.assign({}, this.state.blockInfo);
          newInfo.blocks[0][target.name] = target.value
          this.setState({blockInfoChanged: true, blockInfo: newInfo});
      }

      // Called when a item in the planting details panel is updated.
      this._onPlantingInputChange = function(event) {
          let target = event.target;
          let newInfo = Object.assign({}, this.props.plantingInfo);
          newInfo[target.name] = target.value
          newInfo.data[target.name] = target.value
          this.setState({plantingInfo: newInfo});
          console.log("xxxxxxx onPlanting: ", newInfo);
      }
      this._onPlantingInputChange = this._onPlantingInputChange.bind(this);

      this._onPlantingSelect = function(index) {
          console.log("xxxxx select: ", this.props);
          let epa = this.state.expandedPanelAr.slice();
          epa[0] = true;
          let plantingId =  this.state.blockInfo.plantings[index].planting_id;
          let newState = {
            expandedPanelAr: epa,
          };
          this.setState(newState);

          this.props.fetchPlanting(plantingId);
      }
    } // end constructor

    handleCropChange(event) {
        console.log("crop change: ", event.target.value);
        let newVal = event.target.value;
    }

    handleSelect(activeKey) {
      console.log('set active: ', activeKey);
      if (activeKey === undefined)
          return;

      let epar = this.state.expandedPanelAr.slice();
      epar[activeKey] = !epar[activeKey];
      console.log("set visibility: ", activeKey, ", ", epar);
      this.setState({expandedPanelAr: epar});

    }

    render() {
       let myBlockInfo = this.props.blockInfo ? this.props.blockInfo : this.props.blockInfo;
       if (!myBlockInfo || !myBlockInfo.blocks) {
           return (`Loading.... `);
       }

       console.log("block: ", myBlockInfo);
       let myBlock = myBlockInfo.blocks[0];
       let myPlantings = myBlockInfo.plantings;
       let myRanches = myBlockInfo.ranches;
       let plantingInfo = this.props.plantingInfo ? this.props.plantingInfo : {};
       let cropStageList = [];
       if (plantingInfo.crop_details) 
           cropStageList = plantingInfo.crop_details.crop_stage_list;
       
       let isIrrigationConfigured = myBlock.is_irrigation_config_finished;

        return(
            <Grid fluid={true}>
                <div>Update status -  </div>
                {!isIrrigationConfigured &&
                    <ConfigureIrrigationPanel blockId={myBlock.id} ></ConfigureIrrigationPanel>
                }
                <BlockName onInputChange={this._onBlockInfoChange.bind(this)} blockInfo={myBlockInfo}></BlockName>
                <PanelGroup id="plantings-panel">
                      <Panel eventKey="0" onToggle={() => this.togglePanel(0)} expanded={this.state.expandedPanelAr[0]}>
                        <Panel.Heading>
                            <h4 onClick={() => this.handleSelect(0)} className="panel-title"><i className={'fa fa-fw fa-chevron-' + (this.state.expandedPanelAr[0] ? 'down' : 'up')}></i>Planting Details  - {plantingInfo.name}</h4>
                        </Panel.Heading>
                        <Panel.Body id="planting-details" collapsible>
                            <PlantingDetail onInputChange={this._onPlantingInputChange} planting={plantingInfo}></PlantingDetail>
                        </Panel.Body>
                      </Panel>

                      <Panel eventKey="1" onToggle={() => this.togglePanel(1)} expanded={this.state.expandedPanelAr[1]}>
                        <Panel.Heading>
                            <h4 onClick={() => this.handleSelect(1)} className="panel-title"><i className={'fa fa-fw fa-chevron-' + (this.state.expandedPanelAr[1] ? 'down' : 'up')}></i>Plantings</h4>
                            {isIrrigationConfigured && 
                                <Button style={{marginTop: '-24px'}} className="pull-right" bsSize="small" onClick={this._addPlanting.bind(this)} bsStyle="primary">Add Planting...</Button>
                            }
                        </Panel.Heading>

                        <Panel.Body collapsible>
                            <PlantingsList plantingsList={myBlockInfo.plantings} onPlantingSelect={this._onPlantingSelect.bind(this)} ></PlantingsList>
                        </Panel.Body>
                      </Panel>

                      <Panel eventKey="2" onToggle={() => this.togglePanel(1)} expanded={this.state.expandedPanelAr[2]}>
                        <Panel.Heading>
                            <h4 onClick={() => this.handleSelect(2)} className="panel-title"><i className={'fa fa-fw fa-chevron-' + (this.state.expandedPanelAr[2] ? 'down' : 'up')}></i>Crop Stages & KC Table</h4>
                        </Panel.Heading>
                        <Panel.Body collapsible>
                             <div style={{maxHeight:"200px", overflow:"auto"}}>
                                 <KCTable stageList={cropStageList}></KCTable>
                             </div>
                        </Panel.Body>
                      </Panel>
               </PanelGroup>
               <Row>
                   <div className="pull-right" style={{marginRight: '16px'}}>
                       <Button onClick={this._onSave.bind(this)} bsStyle="success">Save</Button>
                       &nbsp;
                       <Button >Cancel</Button>
                   </div>
               </Row>
                       &nbsp;
            </Grid>
        )
    }
}

withRouter(PlantingsTab);

PlantingsTab.propTypes = {
}

const mapStateToProps = (state) => {
    let retVal = {
        blockInfo : state.blockInfo,
        plantingInfo: state.plantingInfo,
        goodUpdate: state.goodUpdate,
    }
    return  retVal;
};

const mapDispatchToProps = (dispatch) => {
    return {
        fetchPlanting: (id) => dispatch(getPlantingInfo(id)),
        updatePlanting: (planting) => dispatch(savePlantingInfo(planting)),
    }
};

export {PlantingsTab};
export default connect(mapStateToProps, mapDispatchToProps)(PlantingsTab);
