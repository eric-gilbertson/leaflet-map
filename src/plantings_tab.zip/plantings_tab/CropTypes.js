/* 
!!!!!!! DO NOT MODIFY THIS FILE DIRECTLY!!!!!!!
	Use generate_crop_type_constants.py
*/

const CROP_TYPES ={
    "alfalfa": {
        "crop_class": "Field", 
        "id": 2, 
        "can_schedule": false, 
        "name": "Alfalfa"
    }, 
    "onion (dry)": {
        "crop_class": "Row", 
        "id": 55, 
        "can_schedule": true, 
        "name": "Onion (dry)"
    }, 
    "safflower": {
        "crop_class": "???", 
        "id": 64, 
        "can_schedule": true, 
        "name": "Safflower"
    }, 
    "apple": {
        "crop_class": "Orchard", 
        "id": 16, 
        "can_schedule": true, 
        "name": "Apple"
    }, 
    "peas": {
        "crop_class": "Row", 
        "id": 57, 
        "can_schedule": true, 
        "name": "Peas"
    }, 
    "carrots": {
        "crop_class": "Row", 
        "id": 29, 
        "can_schedule": true, 
        "name": "Carrots"
    }, 
    "turfgrass (warm-season)": {
        "crop_class": "Field", 
        "id": 79, 
        "can_schedule": true, 
        "name": "Turfgrass (warm-season)"
    }, 
    "millet": {
        "crop_class": "Row", 
        "id": 49, 
        "can_schedule": true, 
        "name": "Millet"
    }, 
    "pistachios": {
        "crop_class": "Orchard", 
        "id": 3, 
        "can_schedule": true, 
        "name": "Pistachios"
    }, 
    "almonds": {
        "crop_class": "Orchard", 
        "id": 1, 
        "can_schedule": true, 
        "name": "Almonds"
    }, 
    "sugarcane": {
        "crop_class": "Field", 
        "id": 73, 
        "can_schedule": true, 
        "name": "Sugarcane"
    }, 
    "beans (dry)": {
        "crop_class": "Row", 
        "id": 21, 
        "can_schedule": true, 
        "name": "Beans (dry)"
    }, 
    "lentil": {
        "crop_class": "Row", 
        "id": 46, 
        "can_schedule": true, 
        "name": "Lentil"
    }, 
    "beans (pinto)": {
        "crop_class": "Row", 
        "id": 23, 
        "can_schedule": true, 
        "name": "Beans (pinto)"
    }, 
    "cotton": {
        "crop_class": "Row", 
        "id": 34, 
        "can_schedule": true, 
        "name": "Cotton"
    }, 
    "beans (green)": {
        "crop_class": "Row", 
        "id": 22, 
        "can_schedule": true, 
        "name": "Beans (green)"
    }, 
    "sisal": {
        "crop_class": "???", 
        "id": 65, 
        "can_schedule": true, 
        "name": "Sisal"
    }, 
    "vegetables": {
        "crop_class": "Row", 
        "id": 80, 
        "can_schedule": true, 
        "name": "Vegetables"
    }, 
    "onion (green)": {
        "crop_class": "Row", 
        "id": 56, 
        "can_schedule": true, 
        "name": "Onion (green)"
    }, 
    "artichokes": {
        "crop_class": "Row", 
        "id": 17, 
        "can_schedule": true, 
        "name": "Artichokes"
    }, 
    "squash": {
        "crop_class": "Row", 
        "id": 68, 
        "can_schedule": true, 
        "name": "Squash"
    }, 
    "broccoli": {
        "crop_class": "Row", 
        "id": 27, 
        "can_schedule": true, 
        "name": "Broccoli"
    }, 
    "celery": {
        "crop_class": "Row", 
        "id": 30, 
        "can_schedule": true, 
        "name": "Celery"
    }, 
    "table grapes": {
        "crop_class": "Vine", 
        "id": 6, 
        "can_schedule": true, 
        "name": "Table Grapes"
    }, 
    "other": {
        "crop_class": "Other", 
        "id": 100, 
        "can_schedule": false, 
        "name": "Other"
    }, 
    "barley": {
        "crop_class": "Row", 
        "id": 20, 
        "can_schedule": true, 
        "name": "Barley"
    }, 
    "turfgrass (cool-season)": {
        "crop_class": "Field", 
        "id": 78, 
        "can_schedule": true, 
        "name": "Turfgrass (cool-season)"
    }, 
    "beets (table)": {
        "crop_class": "Row", 
        "id": 24, 
        "can_schedule": true, 
        "name": "Beets (table)"
    }, 
    "melon": {
        "crop_class": "Row", 
        "id": 48, 
        "can_schedule": true, 
        "name": "Melon"
    }, 
    "wine grapes": {
        "crop_class": "Vine", 
        "id": 5, 
        "can_schedule": true, 
        "name": "Wine Grapes"
    }, 
    "rice": {
        "crop_class": "Field", 
        "id": 63, 
        "can_schedule": true, 
        "name": "Rice"
    }, 
    "corn (silage)": {
        "crop_class": "Row", 
        "id": 33, 
        "can_schedule": true, 
        "name": "Corn (silage)"
    }, 
    "tomatoes": {
        "crop_class": "Row", 
        "id": 4, 
        "can_schedule": true, 
        "name": "Tomatoes"
    }, 
    "strawberries (mulch)": {
        "crop_class": "Row", 
        "id": 70, 
        "can_schedule": true, 
        "name": "Strawberries (mulch)"
    }, 
    "evergreen": {
        "crop_class": "Orchard", 
        "id": 38, 
        "can_schedule": true, 
        "name": "Evergreen"
    }, 
    "wheat": {
        "crop_class": "Field", 
        "id": 83, 
        "can_schedule": true, 
        "name": "Wheat"
    }, 
    "mustard": {
        "crop_class": "Row", 
        "id": 50, 
        "can_schedule": true, 
        "name": "Mustard"
    }, 
    "grains (winter)": {
        "crop_class": "Row", 
        "id": 41, 
        "can_schedule": true, 
        "name": "Grains (winter)"
    }, 
    "citrus": {
        "crop_class": "Orchard", 
        "id": 9, 
        "can_schedule": true, 
        "name": "Citrus"
    }, 
    "olives for table": {
        "crop_class": "Orchard", 
        "id": 11, 
        "can_schedule": true, 
        "name": "Olives for table"
    }, 
    "raisins": {
        "crop_class": "Vine", 
        "id": 62, 
        "can_schedule": true, 
        "name": "Raisins"
    }, 
    "flax": {
        "crop_class": "Row", 
        "id": 39, 
        "can_schedule": true, 
        "name": "Flax"
    }, 
    "walnuts": {
        "crop_class": "Orchard", 
        "id": 8, 
        "can_schedule": true, 
        "name": "Walnuts"
    }, 
    "peppers": {
        "crop_class": "Row", 
        "id": 58, 
        "can_schedule": true, 
        "name": "Peppers"
    }, 
    "sweet potatoes": {
        "crop_class": "Row", 
        "id": 75, 
        "can_schedule": true, 
        "name": "Sweet potatoes"
    }, 
    "radishes": {
        "crop_class": "Row", 
        "id": 61, 
        "can_schedule": true, 
        "name": "Radishes"
    }, 
    "cucumber": {
        "crop_class": "Row", 
        "id": 35, 
        "can_schedule": true, 
        "name": "Cucumber"
    }, 
    "alfalfa (cycle)": {
        "crop_class": "Field", 
        "id": 14, 
        "can_schedule": true, 
        "name": "Alfalfa (cycle)"
    }, 
    "cabbage": {
        "crop_class": "Row", 
        "id": 28, 
        "can_schedule": true, 
        "name": "Cabbage"
    }, 
    "stone fruits": {
        "crop_class": "Orchard", 
        "id": 69, 
        "can_schedule": true, 
        "name": "Stone fruits"
    }, 
    "avocados": {
        "crop_class": "Orchard", 
        "id": 10, 
        "can_schedule": true, 
        "name": "Avocados"
    }, 
    "sugarbeet": {
        "crop_class": "Row", 
        "id": 72, 
        "can_schedule": true, 
        "name": "Sugarbeet"
    }, 
    "grains (small)": {
        "crop_class": "Row", 
        "id": 40, 
        "can_schedule": true, 
        "name": "Grains (small)"
    }, 
    "improved pasture": {
        "crop_class": "Field", 
        "id": 42, 
        "can_schedule": true, 
        "name": "Improved pasture"
    }, 
    "alfalfa (annual)": {
        "crop_class": "Field", 
        "id": 13, 
        "can_schedule": true, 
        "name": "Alfalfa (annual)"
    }, 
    "sudan grass": {
        "crop_class": "Field", 
        "id": 71, 
        "can_schedule": true, 
        "name": "Sudan grass"
    }, 
    "sunflower": {
        "crop_class": "Field", 
        "id": 74, 
        "can_schedule": true, 
        "name": "Sunflower"
    }, 
    "spinach": {
        "crop_class": "Row", 
        "id": 67, 
        "can_schedule": true, 
        "name": "Spinach"
    }, 
    "lettuce": {
        "crop_class": "Row", 
        "id": 47, 
        "can_schedule": true, 
        "name": "Lettuce"
    }, 
    "asparagus": {
        "crop_class": "Row", 
        "id": 18, 
        "can_schedule": true, 
        "name": "Asparagus"
    }, 
    "oats": {
        "crop_class": "Row", 
        "id": 52, 
        "can_schedule": true, 
        "name": "Oats"
    }, 
    "date palm": {
        "crop_class": "Orchard", 
        "id": 36, 
        "can_schedule": true, 
        "name": "Date palm"
    }, 
    "corn (grain)": {
        "crop_class": "Row", 
        "id": 32, 
        "can_schedule": true, 
        "name": "Corn (grain)"
    }, 
    "kiwifruit": {
        "crop_class": "Orchard", 
        "id": 45, 
        "can_schedule": true, 
        "name": "Kiwifruit"
    }, 
    "eggplant": {
        "crop_class": "Row", 
        "id": 37, 
        "can_schedule": true, 
        "name": "Eggplant"
    }, 
    "watermelon": {
        "crop_class": "Row", 
        "id": 82, 
        "can_schedule": true, 
        "name": "Watermelon"
    }, 
    "potato": {
        "crop_class": "Row", 
        "id": 60, 
        "can_schedule": true, 
        "name": "Potato"
    }, 
    "olives for oil": {
        "crop_class": "Orchard", 
        "id": 7, 
        "can_schedule": true, 
        "name": "Olives for oil"
    }, 
    "sorghum": {
        "crop_class": "Row", 
        "id": 66, 
        "can_schedule": true, 
        "name": "Sorghum"
    }
};

export default CROP_TYPES;
