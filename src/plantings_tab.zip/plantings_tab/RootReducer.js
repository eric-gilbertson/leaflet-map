import { combineReducers } from 'redux'
import { plantingInfo, blockInfo } from './PlantingsReducers'

const rootReducer = combineReducers({
    plantingInfoxx,
    blockInfoxxxx,
})


export default rootReducer;
