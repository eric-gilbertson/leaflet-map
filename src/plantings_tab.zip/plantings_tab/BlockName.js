import React from 'react';
import PropTypes from 'prop-types'
import { Row, Col } from 'react-bootstrap/lib';


const BlockName = ({blockInfo, onInputChange }) => {
    console.log("xxxxxxxx BlockName: ", blockInfo.blocks[0].name);
    return(
                <Row style={{'marginBottom' : '8px'}}>
                    <Col xs={6}>
                        <label htmlFor="blockName">Name</label>
                        <input className="form-control" type="text" onChange={onInputChange} value={blockInfo.blocks[0].name}  name="name"></input>
                    </Col>
                    <Col xs={6}>
                        <label htmlFor="blockRanch">Ranch</label>
                        <br/>
                        <select onChange={onInputChange} value={blockInfo.blocks[0].ranch_id} className="form-control" name="ranch_id">
                            {blockInfo.ranches.map(function (ranch, index) {
                                return (
                                    <option key={index} value={ranch[0]}>{ranch[1]}</option>
                                );
                            })}
                        </select>
                    </Col>
                </Row>
    )
}

BlockName.propTypes = {
  blockInfo: PropTypes.shape(),
  onInputChange: PropTypes.func.isRequired,
}

export {BlockName};

