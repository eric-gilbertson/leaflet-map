import React, { Component } from 'react'
import GoogleMapReact from 'google-map-react'
const AnyReactComponent = ({ text }) => <div>{ text }</div>;

export default class GoogleMap extends Component {
  static defaultProps = {
    center: [36.6777, -121.6555 ],
    zoom: 11
  }

  constructor(props) {
      super(props);

      this.drawMarkers = function() {
          console.log('xxxxxxxxxxxxx draw markers');
      }
  }

  render() {
      return (
        <div className='pwe-map'>
          <GoogleMapReact
            bootstrapURLKeys={{key:'AIzaSyC7Y5R8tIWSHu7qWpmE3RbugSYK8JFYnxM'}}
            defaultCenter={ this.props.center }
            defaultZoom={ this.props.zoom }
            onGoogleApiLoaded={this.drawMarkers.bind(this)}
            yesIWantToUseGoogleMapApiInternals={true}>
            <AnyReactComponent
              lat={ 40.7473310 }
              lng={ -73.8517440 }
              text={ 'Where is Waldo?' }
            />
          </GoogleMapReact>
        </div>
      )
    }
}
