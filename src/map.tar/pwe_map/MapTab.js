/* Description:
 * Top level container for block dialog's configuration tab.
 * Note that the blockInfo struct is inherited from the parent
 * page, e.g no Ajax request for it.
 */
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Alert, ButtonToolbar, Panel, PanelGroup, Button, Grid, Row, Col } from 'react-bootstrap/lib';

import GoogleMap from './GoogleMap';
import LeafletMap from './LeafletMap';

class MapTab extends Component {
    constructor(props) {
      super(props);
 
    } // end constructor

    //NOTE: must return true in order to render.
    shouldComponentUpdate(nextProps, nextState) {
       return true;
    }

    componentWillReceiveProps(nextProps) {
    }

    render() {
        return(
          <div>
            <LeafletMap></LeafletMap>
          </div>
        )
    }
}

withRouter(MapTab);

MapTab.propTypes = {
}

const mapStateToProps = (state) => {
};

const mapDispatchToProps = (dispatch) => {
    return {};
};

export {MapTab};
export default connect(mapStateToProps, mapDispatchToProps)(MapTab);
